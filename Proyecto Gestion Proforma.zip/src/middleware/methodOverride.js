// Middleware para soportar PUT y DELETE desde formularios HTML usando _method
const methodOverride = require('method-override');

module.exports = methodOverride;
